<?php
  if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$contentPage = __DIR__ . '/fornecedores_conteudo.php';
include_once(__DIR__ . '/layout.php');
?>