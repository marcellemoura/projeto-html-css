<?php

$host = 'localhost';
$dbname = 'controledestoque';
$username = 'root';
$password = 'ruabreves86';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['acao'])) {
        $acao = $_POST['acao'];

        if ($acao === 'inserir') {
            $nome = $_POST['NomeRepresentante'];
            $telefone = $_POST['TelefoneRepresentante'];
            $email = $_POST['EmailRepresentante'];
            $fornecedor = $_POST['Fabricante_idFabricante'];
            $usuario = $_POST['Usuario_idUser'];

            $stmt = $pdo->prepare("INSERT INTO representante (NomeRepresentante, TelefoneRepresentante, EmailRepresentante, Fabricante_idFabricante, Usuario_idUser) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$nome, $telefone, $email, $fornecedor, $usuario]);
        } elseif ($acao === 'editar') {
            $nome = $_POST['NomeRepresentante'];
            $telefone = $_POST['TelefoneRepresentante'];
            $email = $_POST['EmailRepresentante'];
            $fornecedor = $_POST['Fabricante_idFabricante'];
            $usuario = $_POST['Usuario_idUser'];
            $id = $_POST['idRepresentante'];

            $stmt = $pdo->prepare("UPDATE representante SET NomeRepresentante = ?, TelefoneRepresentante = ?, EmailRepresentante = ?, Fabricante_idFabricante = ?, Usuario_idUser = ? WHERE idRepresentante = ?");
            $stmt->execute([$nome, $telefone, $email, $fornecedor, $usuario, $id]);
        } elseif ($acao === 'excluir') {
            $id = $_POST['idRepresentante'];

            $stmt = $pdo->prepare("DELETE FROM representante WHERE idRepresentante = ?");
            $stmt->execute([$id]);
        }
    }
}

$stmt = $pdo->query("SELECT * FROM representante");
$representante = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Estoque</title>
    <style>
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
            color: #343a40;
            font-size: 28px;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
        }

        form {
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }

        .form-label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-control.small {
            width: 48%;
        }

        button.btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn-primary {
            background-color: #007bff;
            color: #ffffff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        
        .table {
            width: 100%;
            border-collapse: collapse;
            background-color: #ffffff;
            border-radius: 8px;
            overflow: hidden;
            margin-top: 20px;
            box-sizing: border-box;
        }

        .table th,
        .table td {
            padding: 12px 15px;
            text-align: center;
            border: 1px solid #dee2e6;
        }

        .table thead th {
            background-color: #007bff;
            color: #ffffff;
            font-weight: bold;
        }

        .table tbody tr:nth-child(odd) {
            background-color: #f8f9fa;
        }

        .table tbody tr:hover {
            background-color: #e9ecef;
        }

        .btn-warning {
            background-color: #ffc107;
            color: #212529;
        }

        .btn-warning:hover {
            background-color: #e0a800;
        }

        .btn-danger {
            background-color: #dc3545;
            color: #ffffff;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }

            .form-control {
                width: 100%;
            }

            .table {
                font-size: 12px;
            }

            .form-label {
                font-size: 14px;
            }

            button.btn {
                font-size: 14px;
            }

            .form-control.small {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Cadastrar Representantes</h1>

    <form method="post">
        <input type="hidden" name="acao" value="inserir">
        <input type="hidden" name="idRepresentante" id="idRepresentante">

        <div class="mb-3">
            <label for="nome" class="form-label">Nome Representante</label>
            <input type="text" class="form-control" name="NomeRepresentante" id="nome" required>
        </div>
        <div class="mb-3">
            <label for="telefone" class="form-label">Telefone</label>
            <input type="number" class="form-control" name="TelefoneRepresentante" id="telefone" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" name="EmailRepresentante" id="email" required>
        </div>
        <div class="mb-3">
            <label for="fornecedor" class="form-label">Fornecedora</label>
            <input type="number" class="form-control" name="Fabricante_idFabricante" id="fornecedor" required>
        </div>
        <div class="mb-3">
            <label for="usuario" class="form-label">Usuário</label>
            <input type="text" class="form-control" name="Usuario_idUser" id="usuario" required>
        </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome Representante</th>
                <th>Telefone</th>
                <th>Email</th>
                <th>Fornecedora</th>
                <th>Usuário</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($representante as $rep): ?>
            <tr>
                <td><?= $rep['idRepresentante'] ?></td>
                <td><?= htmlspecialchars($rep['NomeRepresentante']) ?></td>
                <td><?= $rep['TelefoneRepresentante'] ?></td>
                <td><?= $rep['EmailRepresentante'] ?></td>
                <td><?= $rep['Fabricante_idFabricante'] ?></td>
                <td><?= $rep['Usuario_idUser'] ?></td>
                <td>
                    <button class="btn btn-warning btn-sm btn-editar" data-id="<?= $rep['idRepresentante'] ?>" data-nome="<?= htmlspecialchars($rep['NomeRepresentante']) ?>" data-telefone="<?= $rep['TelefoneRepresentante'] ?>" data-email="<?= $rep['EmailRepresentante'] ?>" data-fornecedor="<?= $rep['Fabricante_idFabricante'] ?>" data-usuario="<?= $rep['Usuario_idUser'] ?>">Editar</button>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="acao" value="excluir">
                        <input type="hidden" name="idRepresentante" value="<?= $rep['idRepresentante'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
    document.querySelectorAll('.btn-editar').forEach(button => {
        button.addEventListener('click', () => {
            document.querySelector('[name=acao]').value = 'editar';
            document.querySelector('#idRepresentante').value = button.getAttribute('data-id');
            document.querySelector('#nome').value = button.getAttribute('data-nome');
            document.querySelector('#telefone').value = button.getAttribute('data-telefone');
            document.querySelector('#email').value = button.getAttribute('data-email');
            document.querySelector('#fornecedor').value = button.getAttribute('data-fornecedor');
            document.querySelector('#usuario').value = button.getAttribute('data-usuario');
        });
    });
</script>

</body>
</html>
