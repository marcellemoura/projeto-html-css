<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financeiro - MEDCA</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }

        .container {
            margin-left: 250px; 
            padding: 20px;
            overflow: hidden;
        }

        header {
            background-color: #007BFF;
            padding: 15px;
            color: white;
            text-align: center;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        header h1 {
            font-size: 2rem;
        }

        nav ul {
            list-style-type: none;
            padding: 10px 0;
        }

        nav ul li {
            display: inline;
            margin: 0 15px;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-size: 1.1rem;
        }

        .dashboard,
        .reports,
        .cashflow {
            margin-bottom: 30px;
        }

        h2 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: #007BFF;
        }

        .overview {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }

        .box {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 30%;
        }

        .box h3 {
            font-size: 1.2rem;
            margin-bottom: 10px;
        }

        .reports table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .reports table th,
        .reports table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        .reports table th {
            background-color: #007BFF;
            color: white;
        }

        .cashflow-box {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .cashflow-box label {
            display: block;
            margin: 10px 0 5px;
            font-size: 1rem;
        }

        .cashflow-box input,
        .cashflow-box select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 1rem;
        }

        .cashflow-box button {
            width: 100%;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1.1rem;
            cursor: pointer;
        }

        .cashflow-box button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Financeiro - MEDCA</h1>
            <nav>
                <ul>
                    <li><a href="#">Visão Geral</a></li>
                    <li><a href="/website/pages/relatorios.php">Relatórios</a></li>
                    <li><a href="#">Fluxo de Caixa</a></li>
                </ul>
            </nav>
        </header>

        <section class="dashboard">
            <h2>Visão Geral</h2>
            <div class="overview">
                <div class="box revenue">
                    <h3>Receita Total</h3>
                    <p>R$ 50.000,00</p>
                </div>
                <div class="box expenses">
                    <h3>Despesas Totais</h3>
                    <p>R$ 30.000,00</p>
                </div>
                <div class="box balance">
                    <h3>Saldo Atual</h3>
                    <p>R$ 20.000,00</p>
                </div>
            </div>
        </section>

        <section class="reports">
            <h2>Receita e Despesa</h2>
            <table>
                <thead>
                    <tr>
                        <th>Mês</th>
                        <th>Receita</th>
                        <th>Despesas</th>
                        <th>Lucro</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Outubro</td>
                        <td>R$ 10.000,00</td>
                        <td>R$ 6.000,00</td>
                        <td>R$ 4.000,00</td>
                    </tr>
                    <tr>
                        <td>Novembro</td>
                        <td>R$ 12.000,00</td>
                        <td>R$ 7.000,00</td>
                        <td>R$ 5.000,00</td>
                    </tr>
                    <tr>
                        <td>Dezembro</td>
                        <td>R$ 15.000,00</td>
                        <td>R$ 8.000,00</td>
                        <td>R$ 7.000,00</td>
                    </tr>
                </tbody>
            </table>
        </section>

        <section class="cashflow">
            <h2>Fluxo de Caixa</h2>
            <div class="cashflow-box">
                <label for="amount">Valor</label>
                <input type="number" id="amount" name="amount" placeholder="Valor da Transação">

                <label for="type">Tipo de Transação</label>
                <select id="type" name="type">
                    <option value="income">Receita</option>
                    <option value="expense">Despesa</option>
                </select>

                <button type="submit">Adicionar Transação</button>
            </div>
        </section>
    </div>
</body>
</html>
