<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contato - Setor de T.I</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333333;
        }
        label {
            display: block;
            margin: 15px 0 5px;
            font-weight: bold;
        }
        input, textarea, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #cccccc;
            border-radius: 4px;
            font-size: 16px;
        }
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #0056b3; 
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #777777;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Contato - Setor T.I</h1>
        <form id="contactForm">
            <label for="name">Nome:</label>
            <input type="text" id="name" name="name" placeholder="Digite seu nome" required>

            <label for="phone">Número de Contato:</label>
            <input type="tel" id="phone" name="phone" placeholder="(XX) XXXXX-XXXX" required>

            <label for="message">Observação:</label>
            <textarea id="message" name="message" placeholder="Escreva sua mensagem" required></textarea>

            <button type="button" onclick="sendEmail()">Enviar</button>
        </form>
        
    </div>

    <script>
        function sendEmail() {
            const name = document.getElementById('name').value;
            const phone = document.getElementById('phone').value;
            const message = document.getElementById('message').value;

            if (name && phone && message) {
                const emailBody = `
                    Nome: ${name}%0A
                    Telefone: ${phone}%0A
                    Observação: ${message}%0A
                `;
                const mailToLink = `mailto:suporte.ti@exemplo.com?subject=Contato%20Setor%20T.I&body=${emailBody}`;
                window.location.href = mailToLink;
            } else {
                alert("Por favor, preencha todos os campos");
            }
        }
    </script>
</body>
</html>
