<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boletos - Medca</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }

        .container {
            margin-left: 250px; 
            padding: 20px;
        }

        header {
            background-color: #007BFF;
            padding: 15px;
            color: white;
            text-align: center;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        header h1 {
            font-size: 2rem;
        }

        nav ul {
            list-style-type: none;
            padding: 10px 0;
        }

        nav ul li {
            display: inline;
            margin: 0 15px;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-size: 1.1rem;
        }

        h2 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: #007BFF;
        }

        section {
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th,
        table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        table th {
            background-color: #007BFF;
            color: white;
        }

        .boleto-actions {
            margin-bottom: 20px;
        }

        .add-boleto-btn {
            background-color: #808080;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
        }

        .add-boleto-btn:hover {
            background-color: #606060;
        }

        .pay-boleto-btn, .view-boleto-btn {
            background-color: #808080;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9rem;
        }

        .pay-boleto-btn:hover, .view-boleto-btn:hover {
            background-color: #606060;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Boletos - MEDCA</h1>
            <nav>
                <ul>
                    <li><a href="/website/pages/index.php">Página Inicial</a></li>
                    <li><a href="#">Emissão de Boletos</a></li>
                    <li><a href="#">Consultas de Boletos</a></li>
                    <li><a href="/website/pages/relatorios.php">Relatórios Financeiros</a></li>
                </ul>
            </nav>
        </header>

        <section class="boletos-info">
            <h2>Informações de Boletos Emitidos</h2>
            <div class="boleto-actions">
                <button class="add-boleto-btn">Emitir Novo Boleto</button>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Código do Boleto</th>
                        <th>Data de Vencimento</th>
                        <th>Valor</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>123456789</td>
                        <td>15/12/2024</td>
                        <td>R$ 850,00</td>
                        <td>Pendente</td>
                        <td>
                            <button class="view-boleto-btn">Visualizar</button>
                            <button class="pay-boleto-btn">Pagar</button>
                        </td>
                    </tr>
                    <tr>
                        <td>987654321</td>
                        <td>20/12/2024</td>
                        <td>R$ 1.200,00</td>
                        <td>Pago</td>
                        <td>
                            <button class="view-boleto-btn">Visualizar</button>
                        </td>
                    </tr>
                    <tr>
                        <td>543216789</td>
                        <td>25/12/2024</td>
                        <td>R$ 420,00</td>
                        <td>Pendente</td>
                        <td>
                            <button class="view-boleto-btn">Visualizar</button>
                            <button class="pay-boleto-btn">Pagar</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </section>
    </div>
</body>
</html>
