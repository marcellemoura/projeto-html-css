<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Movimentações Prod.</title>
  <style>
    @charset "UTF-8";
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f5f5f5;
    }

    .container {
      max-width: 1200px; 
      margin: 20px auto;
      background: #ffffff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      
    }
    

    h1, h2 {
      text-align: center;
      color: #333;
    }

    h2 {
      font-size: 20px; 
    }

    form {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-bottom: 20px;
    }

    form input, form select, form button {
      padding: 12px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 4px;
      width: 48%;
    }

    form button {
      background-color: #007BFF;
      color: #fff;
      cursor: pointer;
      width: 100%;
      margin-top: 10px;
    }

    form button:hover {
      background-color: #0056b3;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      border-radius: 8px;
      overflow: hidden;
      table-layout: fixed; 
      font-size: 12px; 
    }

    table th, table td {
      border: 1px solid #ddd;
      padding: 10px 12px; 
      text-align: center;
      word-wrap: break-word; 
      overflow-wrap: break-word; 
    }

    table th {
      background-color: #f4f4f4;
      color: #333;
    }

    table th:nth-child(11), table td:nth-child(11) {
      width: 15%; 
    }

    table th:nth-child(1), table td:nth-child(1) {
      width: 8%;
    }
    table th:nth-child(2), table td:nth-child(2) {
      width: 10%;
    }
    table th:nth-child(3), table td:nth-child(3) {
      width: 10%;
    }
    table th:nth-child(4), table td:nth-child(4) {
      width: 12%;
    }
    table th:nth-child(5), table td:nth-child(5) {
      width: 12%;
    }
    table th:nth-child(6), table td:nth-child(6) {
      width: 12%;
    }
    table th:nth-child(7), table td:nth-child(7) {
      width: 12%;
    }
    table th:nth-child(8), table td:nth-child(8) {
      width: 10%;
    }
    table th:nth-child(9), table td:nth-child(9) {
      width: 10%;
    }
    table th:nth-child(10), table td:nth-child(10) {
      width: 10%;
    }

    table tbody tr:nth-child(odd) {
      background-color: #fafafa;
    }

    table tbody tr:hover {
      background-color: #f1f1f1;
    }

    .table-empty {
      text-align: center;
      font-style: italic;
      color: #888;
    }

    .export-btn {
      display: inline-block;
      background-color: #007BFF;
      color: #fff;
      padding: 10px 20px;
      border-radius: 4px;
      text-align: center;
      cursor: pointer;
      text-decoration: none;
      margin-top: 20px;
    }

    .export-btn:hover {
      background-color: #0056b3;
    }

  </style>
</head>
<body>
  <div class="container">
    
    <div class="form-section">
      <h2>Adicionar Produto</h2>
      <form id="form-add-product">
        <input type="number" id="id-product" placeholder="CodRef do Produto" required>
        <input type="number" id="product-quantity" placeholder="Quantidade Inicial" min="0" required>
        <button type="submit">Adicionar</button>
      </form>
    </div>
    
    <div class="form-section">
      <h2>Registrar Movimentação</h2>
      <form id="form-movement">
        <select id="product-select" required></select>
        <select id="movement-type">
          <option value="entrada">Entrada</option>
          <option value="saida">Saída</option>
        </select>
        <input type="number" id="movement-quantity" placeholder="Quantidade" min="1" required>

        
        <input type="date" id="movement-date" placeholder="Data da Movimentação" required>
        
        <button type="submit">Registrar</button>
      </form>
    </div>

    <div class="movement-section">
      <h2>Movimentações</h2>
      <table id="movement-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>QTD</th>
            <th>Qtd Saída</th>
            <th>Valor de Compra</th>
            <th>Valor de Venda</th>
            <th>Data Compra</th>
            <th>Data Venc</th>
            <th>Código Ref</th>
            <th>FORNEC</th>
            <th>Usuário</th>
            <th>Data de Movimentação</th> 
          </tr>
        </thead>
        <tbody id="productTableBody">
          <tr>
            <td>1</td>
            <td>100</td>
            <td>20</td>
            <td>R$ 15,00</td>
            <td>R$ 25,00</td>
            <td>2024-11-01</td>
            <td>2025-11-01</td>
            <td>ABC123</td>
            <td>Fornecedor A</td>
            <td>Usuario 1</td>
            <td>2024-11-15</td> 
          </tr>
          <tr>
            <td>2</td>
            <td>200</td>
            <td>50</td>
            <td>R$ 10,00</td>
            <td>R$ 20,00</td>
            <td>2024-11-05</td>
            <td>2025-11-05</td>
            <td>DEF456</td>
            <td>Fornecedor B</td>
            <td>Usuario 2</td>
            <td>2024-11-10</td> 
          </tr>
          <tr>
            <td>3</td>
            <td>150</td>
            <td>30</td>
            <td>R$ 12,00</td>
            <td>R$ 22,00</td>
            <td>2024-11-10</td>
            <td>2025-11-10</td>
            <td>XYZ789</td>
            <td>Fornecedor C</td>
            <td>Usuario 3</td>
            <td>2024-11-12</td> 
          </tr>
        </tbody>
      </table>
      <a href="#" class="export-btn" id="export-btn">Baixar Planilha</a>
    </div>
  </div>

  <script>
    const inventory = [];
    const movements = [];

    
    function updateInventoryTable() {
      const tableBody = document.querySelector("#inventory-table tbody");
      tableBody.innerHTML = "";

      if (inventory.length === 0) {
        tableBody.innerHTML = "<tr><td colspan='2' class='table-empty'>Nenhum produto no estoque</td></tr>";
        return;
      }

      inventory.forEach((product) => {
        const row = `<tr>
          <td>${product.name}</td>
          <td>${product.quantity}</td>
        </tr>`;
        tableBody.innerHTML += row;
      });
    }

    
    function updateMovementTable() {
      const tableBody = document.querySelector("#movement-table tbody");
      tableBody.innerHTML = "";

      if (movements.length === 0) {
        tableBody.innerHTML = "<tr><td colspan='4' class='table-empty'>Nenhuma movimentação registrada</td></tr>";
        return;
      }

      movements.forEach((movement) => {
        const row = `<tr>
          <td>${movement.product}</td>
          <td>${movement.type}</td>
          <td>${movement.quantity}</td>
          <td>${movement.done ? "Realizada" : "Pendente"}</td>
          <td>${movement.date}</td> <!-- Exibindo a data da movimentação -->
        </tr>`;
        tableBody.innerHTML += row;
      });
    }

    
    function exportTableToCSV() {
      const rows = document.querySelectorAll('#movement-table tr');
      let csvContent = 'ID,Quantidade,Qtd Saída,Valor de Compra,Valor de Venda,Data Compra,Data Vencimento,Código Ref,Fornecedor,Usuário,Data de Movimentação\n';

      rows.forEach((row, index) => {
        const columns = row.querySelectorAll('td, th');
        const rowData = [];
        columns.forEach(col => rowData.push(col.innerText));
        if (index > 0) { 
          csvContent += rowData.join(',') + '\n';
        }
      });

      
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'movimentacoes.csv';
      link.click();
    }

    
    document.getElementById('export-btn').addEventListener('click', (e) => {
      e.preventDefault();
      exportTableToCSV();
    });
  </script>
</body>
</html>
