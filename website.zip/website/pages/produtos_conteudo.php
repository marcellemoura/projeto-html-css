<?php

$host = 'localhost';
$dbname = 'controledestoque';
$username = 'root';
$password = 'ruabreves86';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['acao'])) {
        $acao = $_POST['acao'];

        if ($acao === 'inserir') {
            $nome = $_POST['nome'];
            $quantidade = $_POST['quantidade'];
            $valor = $_POST['valor'];
            $categoria = $_POST['categoria'];

            $stmt = $pdo->prepare("INSERT INTO produtos (nome, quantidade, valor ,categoria) VALUES (?, ?, ?,?)");
            $stmt->execute([$nome, $quantidade, $valor, $categoria]);
        } elseif ($acao === 'editar') {
            $id = $_POST['id'];
            $nome = $_POST['nome'];
            $quantidade = $_POST['quantidade'];
            $valor = $_POST['valor'];
            $categoria = $_POST['categoria'];

            $stmt = $pdo->prepare("UPDATE produtos SET nome = ?, quantidade = ?, valor = ?, categoria = ? WHERE id = ?");
            $stmt->execute([$nome, $quantidade, $valor, $categoria, $id]);
        } elseif ($acao === 'excluir') {
            $id = $_POST['id'];

            $stmt = $pdo->prepare("DELETE FROM produtos WHERE id = ?");
            $stmt->execute([$id]);
        }
    }
}

$stmt = $pdo->query("SELECT * FROM produtos");
$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Estoque</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        
        body, html {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        
        .container {
           
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            padding: 20px;
        }

        h1 {
            color: #343a40;
        }

        
        form {
            width: 100%;
            max-width: 800px;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .form-label {
            font-weight: bold;
        }

        .form-control {
            margin-bottom: 15px;
        }

        button.btn {
            width: 100%;
        }

        
        .table {
            width: 100%;
            max-width: 1200px;
            margin-top: 30px;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            text-align: center; 
            padding: 12px;
            border: 1px solid #dee2e6;
            vertical-align: middle; 
        }

        .table thead th {
            background-color: #007bff;
            color: white;
        }

        .table tbody tr:nth-child(odd) {
            background-color: #f8f9fa;
        }

        .table tbody tr:hover {
            background-color: #e9ecef;
        }

        
        .actions {
            display: flex;
            justify-content: space-between; 
            gap: 10px; 
            width: 100%; 
            padding: 0; 
            margin: 0;  
        }

        .btn-warning, .btn-danger {
            flex: 1; 
            padding: 10px 20px; 
        }

        
        .content-wrapper {
            flex: 1;
            padding: 20px;
        }
    </style>
</head>
<body>


<div class="content-wrapper">
    <div class="container">
        <h1>Gerenciar Produtos</h1>
        <form method="post" id="productForm"> 
            <input type="hidden" name="acao" value="inserir" id="acao"> 
            <input type="hidden" name="id" id="id"> 
            <div class="form-group"> 
                <label for="nome" class="form-label">Nome do Produto</label> 
                <input type="text" class="form-control" name="nome" id="nome" required> 
            </div> 
            <div class="form-group"> 
                <label for="valor" class="form-label">Preço</label> 
                <input type="number" step="0.01" class="form-control" name="valor" id="valor" required> 
            </div> 
            <div class="form-group"> 
                <label for="quantidade" class="form-label">Quantidade</label> 
                <input type="number" class="form-control" name="quantidade" id="quantidade" required> 
            </div> <div class="form-group"> 
                <label for="categoria" class="form-label">Categoria</label> 
                <input type="text" class="form-control" name="categoria" id="categoria" required> </div> 
                <button type="submit" class="btn btn-primary">Salvar</button> 
            </form>

        
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Preço</th>
                    <th>Quantidade</th>
                    <th>Categoria</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produtos as $produto): ?>
                    <tr>
                        <td><?= $produto['id'] ?></td>
                        <td><?= htmlspecialchars($produto['nome']) ?></td>
                        <td><?= $produto['quantidade']?></td>
                        <td><?=  number_format($produto['valor'], 2, ',', '.') ?></td>
                        <td><?= $produto['categoria']?></td>
                        <td class="actions">
                             <button type="button" class="btn btn-warning btn-editar" 
                                     data-id="<?= $produto['id'] ?>" 
                                     data-nome="<?= htmlspecialchars($produto['nome']) ?>" 
                                     data-quantidade="<?= $produto['quantidade'] ?>" 
                                     data-valor="<?= $produto['valor'] ?>" 
                                     data-categoria="<?= htmlspecialchars($produto['categoria']) ?>">Editar</button> 
                            <form method="post" style="width: 48%; padding: 0; margin: 0;"> 
                                 <input type="hidden" name="acao" value="excluir"> 
                                 <input type="hidden" name="id" value="<?= $produto['id'] ?>"> 
                                 <button type="submit" class="btn btn-danger">Excluir</button> </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
    document.querySelectorAll('.btn-editar').forEach(button => { 
        button.addEventListener('click', () => { 
            const form = document.querySelector('#productForm'); document.querySelector('#acao').value = 'editar'; 
            document.querySelector('#id').value = button.getAttribute('data-id'); 
            document.querySelector('#nome').value = button.getAttribute('data-nome'); 
            document.querySelector('#quantidade').value = button.getAttribute('data-quantidade'); 
            document.querySelector('#valor').value = button.getAttribute('data-valor'); 
            document.querySelector('#categoria').value = button.getAttribute('data-categoria'); }); });
</script>


</body>
</html>
