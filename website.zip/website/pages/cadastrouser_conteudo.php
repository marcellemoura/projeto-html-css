<?php

$host = 'localhost';
$dbname = 'controledestoque';
$username = 'root';
$password = 'ruabreves86';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['acao'])) {
        $acao = $_POST['acao'];

        if ($acao === 'inserir') {
            $nome = $_POST['Username'];
            $email = $_POST['E-mail'];
            $senha = $_POST['Password'];
            $dataregistro = $_POST['Dataregistro'];
            $permissao = $_POST['Permissão'];

            $stmt = $pdo->prepare("INSERT INTO usuario (`Username`, `E-mail`, `Password`, `Dataregistro`, `Permissão`) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$nome, $email, $senha, $dataregistro, $permissao]);
        } elseif ($acao === 'editar') {
            $id = $_POST['idUser'] ?? null; 
            $nome = $_POST['Username'];
            $email = $_POST['E-mail'];
            $senha = $_POST['Password'];
            $dataregistro = $_POST['Dataregistro'];
            $permissao = $_POST['Permissão'];

            if ($id) {
                $stmt = $pdo->prepare("UPDATE usuario SET `Username` = ?, `E-mail` = ?, `Password` = ?, `Dataregistro` = ?, `Permissão` = ? WHERE `idUser` = ?");
                $stmt->execute([$nome, $email, $senha, $dataregistro, $permissao, $id]);
            } else {
                echo "ID do usuário não foi fornecido para edição.";
            }
        } elseif ($acao === 'excluir') {
            $id = $_POST['idUser'] ?? null; 

            if ($id) {
                $stmt = $pdo->prepare("DELETE FROM usuario WHERE `idUser` = ?");
                $stmt->execute([$id]);
            } else {
                echo "ID do usuário não foi fornecido para exclusão.";
            }
        }
    }
}

$stmt = $pdo->query("SELECT * FROM usuario");
$usuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Estoque</title>
    <style>
         
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            height: 100vh;
        }

        .crud-wrapper {
            background-color: #fff;
            padding: 20px;
            max-width: 1000px; 
            width: 100%;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-left: 250px; 
        }

        .crud-wrapper h1 {
            text-align: center;
            margin-bottom: 10px; 
            color: #343a40;
            font-size: 24px; 
        }

        .crud-wrapper form {
            margin-bottom: 20px;
        }

        .crud-wrapper .form-label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
        }

        .crud-wrapper .form-control {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ced4da;
            border-radius: 4px;
        }

        .crud-wrapper .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px; 
            margin-right: 10px; 
            display: inline-block;
            vertical-align: middle;
        }

        .crud-wrapper .btn-primary {
            background-color: #6c757d; 
            color: white;
        }

        .crud-wrapper .btn-primary:hover {
            background-color: #5a6268; 
        }

        .crud-wrapper .btn-warning {
            background-color: #ffc107; 
            color: white;
        }

        .crud-wrapper .btn-warning:hover {
            background-color: #e0a800; 
        }

        .crud-wrapper .btn-danger {
            background-color: #dc3545;
            color: white;
        }

        .crud-wrapper .btn-danger:hover {
            background-color: #c82333;
        }

        .crud-wrapper .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 14px; 
        }

        .crud-wrapper .table th,
        .crud-wrapper .table td {
            padding: 8px; 
            text-align: center; 
            border: 1px solid #dee2e6;
        }

        .crud-wrapper .table thead th {
            background-color: #6c757d; 
            color: white;
        }

        .crud-wrapper .table tbody tr:nth-child(odd) {
            background-color: #f8f9fa;
        }

        .crud-wrapper .table tbody tr:hover {
            background-color: #e9ecef;
        }

        
        .actions {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        
        .crud-wrapper .btn {
            height: 36px; 
        }

        
        .actions form {
            margin: 0;
        }
    </style>
</head>
<body>
    </style>
</head>
<body>

<div class="crud-wrapper">
    <div class="container">
        <h1>Cadastro de Usuários</h1>
        <form method="post" id="userForm">  
            <input type="hidden" name="acao" value="inserir" id="acao">
            <input type="hidden" name="idUser" id="idUser">

            <label class="form-label" for="Username">Nome</label>
            <input type="text" class="form-control" name="Username" id="Username" required>

            <label class="form-label" for="E-mail">E-mail</label>
            <input type="text" class="form-control" name="E-mail" id="E-mail" required>

            <label class="form-label" for="Password">Senha</label>
            <input type="password" class="form-control" name="Password" id="Password" required>

            <label class="form-label" for="Dataregistro">Data de Registro</label>
            <input type="date" class="form-control" name="Dataregistro" id="Dataregistro" required>

            <label class="form-label" for="Permissão">Permissão</label>
            <input type="text" class="form-control" name="Permissão" id="Permissão" required>

            <button type="submit" class="btn btn-primary">Salvar</button>
        </form>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Senha</th>
                    <th>Data de Registro</th>
                    <th>Permissão</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuario as $usuario): ?>
                    <tr>
                        <td><?= $usuario['idUser'] ?></td>
                        <td><?= htmlspecialchars($usuario['Username']) ?></td>
                        <td><?= $usuario['E-mail'] ?></td>
                        <td><?= $usuario['Password'] ?></td>
                        <td><?= $usuario['Dataregistro'] ?></td>
                        <td><?= $usuario['Permissão'] ?></td>
                        <td class="actions">
                            <button type="button" class="btn btn-warning btn-editar"
                                    data-id="<?= $usuario['idUser'] ?>"
                                    data-nome="<?= htmlspecialchars($usuario['Username']) ?>"
                                    data-email="<?= $usuario['E-mail'] ?>"
                                    data-senha="<?= $usuario['Password'] ?>"
                                    data-dataregistro="<?= $usuario['Dataregistro'] ?>"
                                    data-permissao="<?= $usuario['Permissão'] ?>">Editar</button>
                            <form method="post" style="width: 48%; padding: 0; margin: 0;">
                                <input type="hidden" name="acao" value="excluir">
                                <input type="hidden" name="idUser" value="<?= $usuario['idUser'] ?>">
                                <button type="submit" class="btn btn-danger">Excluir</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    document.querySelectorAll('.btn-editar').forEach(button => {
        button.addEventListener('click', () => {
            const form = document.querySelector('#userForm');
            document.querySelector('#acao').value = 'editar';
            document.querySelector('#idUser').value = button.getAttribute('data-id');
            document.querySelector('#Username').value = button.getAttribute('data-nome');
            document.querySelector('#E-mail').value = button.getAttribute('data-email');
            document.querySelector('#Password').value = button.getAttribute('data-senha');
            document.querySelector('#Dataregistro').value = button.getAttribute('data-dataregistro');
            document.querySelector('#Permissão').value = button.getAttribute('data-permissao');
        });
    });
</script>

</body>
</html>
