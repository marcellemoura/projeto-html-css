<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Buscar Produtos</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }

    .container {
      max-width: 900px;
      margin: 20px auto;
      background: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 20px;
      font-size: 30px; 
    }

    .filters {
      display: flex;
      flex-direction: column;
      gap: 15px;
      margin-bottom: 30px;
    }

    .filters label {
      font-weight: bold;
      color: #555;
    }

    .filters select, .filters input, .filters button {
      padding: 10px;
      font-size: 16px;
      width: 100%;
      max-width: 350px;
      margin-top: 5px;
      border-radius: 5px;
      border: 1px solid #ddd;
    }

    .filters select, .filters input {
      background-color: #fafafa;
    }

    button {
      background-color: #007bff;
      color: white;
      border: none;
      cursor: pointer;
      width: 100%;
      max-width: 350px;
      border-radius: 5px;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #0056b3;
    }

    .results {
      margin-top: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    table th, table td {
      border: 1px solid #ddd;
      padding: 12px;
      text-align: center;
    }

    table th {
      background-color: #f4f4f4;
      color: #333;
    }

    table td {
      background-color: #fafafa;
    }

    table tr:nth-child(even) td {
      background-color: #f9f9f9;
    }

    table td {
      font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Buscar Produtos</h1>

    <div class="filters">
      <label for="category-filter">Categoria:</label>
      <select id="category-filter">
        <option value="">Selecione uma categoria</option>
        <option value="insumos">Insumos</option>
        <option value="medicacao">Medicações</option>
      </select>

      <label for="purchase-date-filter">Data de Compra:</label>
      <input type="date" id="purchase-date-filter">

      <label for="expiry-date-filter">Data de Validade:</label>
      <input type="date" id="expiry-date-filter">

      <button onclick="filterProducts()">Filtrar Produtos</button>
    </div>

    <div class="results">
      <h2>Resultados da Busca</h2>
      <table id="product-table">
        <thead>
          <tr>
            <th>Produto</th>
            <th>Categoria</th>
            <th>Data de Compra</th>
            <th>Data de Validade</th>
            <th>Quantidade</th>
            <th>Preço Unitário</th>
            <th>Valor Total</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td colspan="7">Nenhum produto encontrado.</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <script>
    const products = [
      { name: "-", category: "insumos", purchaseDate: "2024-01-15", expiryDate: "2026-01-15", quantity: 20, unitPrice: 1500 },
      { name: "-", category: "insumos", purchaseDate: "2023-06-10", expiryDate: "2028-06-10", quantity: 50, unitPrice: 200 },
      { name: "-", category: "medicacao", purchaseDate: "2024-01-01", expiryDate: "2025-12-31", quantity: 100, unitPrice: 5 },
      { name: "-", category: "medicacao", purchaseDate: "2023-11-20", expiryDate: "2025-11-20", quantity: 150, unitPrice: 40 },
    ];

    function filterProducts() {
      const categoryFilter = document.getElementById("category-filter").value;
      const purchaseDateFilter = document.getElementById("purchase-date-filter").value;
      const expiryDateFilter = document.getElementById("expiry-date-filter").value;

      const filteredProducts = products.filter(product => {
        const matchesCategory = categoryFilter ? product.category === categoryFilter : true;
        const matchesPurchaseDate = purchaseDateFilter ? product.purchaseDate >= purchaseDateFilter : true;
        const matchesExpiryDate = expiryDateFilter ? product.expiryDate <= expiryDateFilter : true;

        return matchesCategory && matchesPurchaseDate && matchesExpiryDate;
      });

      updateProductTable(filteredProducts);
    }

    function updateProductTable(filteredProducts) {
      const tableBody = document.querySelector("#product-table tbody");
      tableBody.innerHTML = "";

      if (filteredProducts.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="7">Nenhum produto encontrado.</td></tr>`;
        return;
      }

      filteredProducts.forEach(product => {
        const totalValue = (product.quantity * product.unitPrice).toFixed(2);
        tableBody.innerHTML += `
          <tr>
            <td>${product.name}</td>
            <td>${product.category}</td>
            <td>${product.purchaseDate}</td>
            <td>${product.expiryDate}</td>
            <td>${product.quantity}</td>
            <td>R$ ${product.unitPrice.toFixed(2)}</td>
            <td>R$ ${totalValue}</td>
          </tr>
        `;
      });
    }

    updateProductTable(products);
  </script>
</body>
</html>
