<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload de Documentos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
        }

        
        .page-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        
        .container {
            text-align: center;
            padding: 40px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 600px;
            width: 90%;
        }

        .container h1 {
            margin-bottom: 20px;
            color: #333;
        }

        .container p {
            font-size: 0.9rem;
            color: #555;
            margin-bottom: 20px;
        }

        .container form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .container .file-label {
            font-size: 1.2rem;
            color: #333;
        }

        .container input[type="file"] {
            padding: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            background-color: #fafafa;
            font-size: 1rem;
        }

        .container button {
            padding: 15px;
            color: #fff;
            background-color: #007BFF;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }

        .container button:hover {
            background-color: #0056cc;
        }
    </style>
</head>
<body>
    <div class="page-wrapper">
        <div class="container">
            <h1>Envio de Documentos</h1>
            <p>Este formulário deve ser utilizado exclusivamente para o envio de documentos muito importantes da empresa. Certifique-se de que o arquivo enviado está correto e completo.</p>
            <form action="/upload" method="post" enctype="multipart/form-data">
                <label for="file-upload" class="file-label">Selecione o arquivo:</label>
                <input type="file" id="file-upload" name="file" required>
                <button type="submit">Enviar</button>
            </form>
        </div>
    </div>
</body>
</html>
