<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Atividades abertas</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
      color: #343a40;
    }

    header {
      background-color: #007bff;
      color: white;
      text-align: center;
      padding: 20px;
    }

    main {
      max-width: 900px;
      margin: 20px auto;
      padding: 20px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    h1 {
      font-size: 24px;
      margin-bottom: 20px;
    }

    h2 {
      font-size: 20px;
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    table th, table td {
      padding: 12px;
      border: 1px solid #dee2e6;
      text-align: center;
      font-size: 14px;
    }

    table th {
      background-color: #f1f1f1;
      font-weight: 600;
    }

    table td {
      background-color: #ffffff;
    }

    table tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    #activity-actions form {
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }

    #activity-actions form label {
      font-size: 14px;
      font-weight: 600;
      margin-right: 10px;
      width: 150px;
    }

    #activity-actions input, #activity-actions select, #activity-actions button {
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 14px;
      width: 200px;
    }

    #activity-actions button {
      background-color: #28a745;
      color: white;
      cursor: pointer;
      border: none;
      width: auto;
    }

    #activity-actions button:hover {
      background-color: #218838;
    }

    #add-activity-form input, #add-activity-form button {
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
    }

    #add-activity-form button {
      background-color: #007bff;
      color: white;
      cursor: pointer;
      border: none;
    }

    #add-activity-form button:hover {
      background-color: #0056b3;
    }

    #add-activity-form {
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <header>
    <h1>Gestão de Atividades</h1>
  </header>

  <main>
    <section id="activity-list">
      <h2>Atividades Pendentes</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Descrição</th>
            <th>Usuário</th>
            <th>Prazo</th>
          </tr>
        </thead>
        <tbody id="open-activities">
          
        </tbody>
      </table>
    </section>

    <section id="activity-actions">
      <h2>Ações</h2>
      <form id="update-activity">
        <div>
          <label for="activity-id">ID da Atividade:</label>
          <input type="number" id="activity-id" required>
        </div>

        <div>
          <label for="status">Status:</label>
          <select id="status" required>
            <option value="solved">Solucionada</option>
            <option value="pending">Pendente</option>
          </select>
        </div>

        <div>
          <label for="worker">Tarefa Realizada por:</label>
          <input type="text" id="worker" required>
        </div>

        <button type="submit">Atualizar Status</button>
      </form>
    </section>

    <section id="add-activity">
      <h2>Adicionar Nova Atividade</h2>
      <form id="add-activity-form">
        <div>
          <label for="description">Descrição:</label>
          <input type="text" id="description" required>
        </div>

        <div>
          <label for="user">Usuário:</label>
          <input type="text" id="user" required>
        </div>

        <div>
          <label for="deadline">Prazo:</label>
          <input type="date" id="deadline" required>
        </div>

        <button type="submit">Adicionar</button>
      </form>
    </section>
  </main>

  <script>
    let activities = [
      {
        id: 1,
        description: "Revisar inventário do armazém",
        user: "Carlos Silva",
        deadline: "2024-11-20",
        status: "open",
        worker: ""
      },
      {
        id: 2,
        description: "Atualizar o sistema com novos produtos",
        user: "Ana Oliveira",
        deadline: "2024-11-22",
        status: "open",
        worker: ""
      },
    ];

    function renderOpenActivities() {
      const openActivities = document.getElementById("open-activities");
      openActivities.innerHTML = "";

      activities
        .filter((activity) => activity.status === "open")
        .forEach((activity) => {
          const row = document.createElement("tr");
          row.innerHTML = `
            <td>${activity.id}</td>
            <td>${activity.description}</td>
            <td>${activity.user}</td>
            <td>${activity.deadline}</td>
          `;
          openActivities.appendChild(row);
        });
    }

    document.getElementById("update-activity").addEventListener("submit", (e) => {
      e.preventDefault();

      const activityId = parseInt(document.getElementById("activity-id").value);
      const newStatus = document.getElementById("status").value;
      const workerName = document.getElementById("worker").value;

      const activity = activities.find((act) => act.id === activityId);
      if (activity) {
        activity.status = newStatus;
        activity.worker = workerName;
        renderOpenActivities();
        alert(`Atividade #${activityId} atualizada para "${newStatus}" e realizada por ${workerName}.`);
      } else {
        alert(`Atividade #${activityId} não encontrada.`);
      }
    });

    let nextId = activities.length + 1;

    document.getElementById("add-activity-form").addEventListener("submit", (e) => {
      e.preventDefault();

      const description = document.getElementById("description").value;
      const user = document.getElementById("user").value;
      const deadline = document.getElementById("deadline").value;

      activities.push({
        id: nextId++,
        description,
        user,
        deadline,
        status: "open",
        worker: ""
      });

      e.target.reset();
      renderOpenActivities();
      alert("Nova atividade adicionada com sucesso!");
    });

    renderOpenActivities();
  </script>
</body>
</html>
