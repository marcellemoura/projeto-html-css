<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações e Privacidade</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }

        
        .container {
            margin-left: 250px; 
            padding-top: 60px; 
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        
        h1 {
            text-align: center;
            font-size: 1.8rem; 
            margin-bottom: 40px; 
            color: #333;
        }

        .content {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap; 
        }

        
        .settings-form {
            flex: 1;
            max-width: 500px;
            min-width: 300px;
        }

        fieldset {
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        legend {
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 10px;
            color: #333;
        }

        label {
            display: block;
            margin: 10px 0;
        }

        input[type="checkbox"], select {
            margin-right: 10px;
        }

        button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
        }

        button:hover {
            background-color: #0056b3;
        }

        
        .policy {
            flex: 1;
            background-color: #eae6e6;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            min-width: 300px;
        }

        .policy h2 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: #333;
        }

        .policy p {
            font-size: 0.9em;
            color: #555;
            line-height: 1.6;
        }

        
        body.modo-escuro {
            background-color: #333;
            color: #fff;
        }

        body.modo-escuro .container {
            background-color: #444;
            color: #fff;
        }

        body.modo-escuro h1, body.modo-escuro .policy h2, body.modo-escuro legend {
            color: #fff; 
        }

        body.modo-escuro label, body.modo-escuro .policy p {
            color: #ddd; 
        }

        body.modo-escuro button {
            background-color: #0056b3;
        }

        
        body.modo-escuro .policy {
            background-color: #555; 
        }

    </style>
</head>
<body>

    

    <div class="container">
        <h1>Configurações do Sistema</h1>

        <div class="content">
            
            <div class="settings-form">
                <form id="configForm">
                    <fieldset>
                        <legend>Configurações Gerais</legend>
                        <label>
                            <input type="checkbox" id="modoEscuro">
                            Ativar modo escuro
                        </label>
                        <label>
                            <input type="checkbox" id="notificacoes">
                            Ativar notificações
                        </label>
                        <label>
                            Visibilidade do perfil:
                            <select id="privacidade">
                                <option value="Pública">Pública</option>
                                <option value="Privada">Privada</option>
                                <option value="Somente amigos">Somente amigos</option>
                            </select>
                        </label>
                    </fieldset>
                    <button type="button" onclick="salvarConfiguracoes()">Salvar Configurações</button>
                </form>
            </div>

            
            <div class="policy">
                <h2>Política de Privacidade</h2>
                <p>Este sistema respeita sua privacidade e garante que seus dados estão seguros. As configurações de privacidade permitem controlar como suas informações serão compartilhadas.</p>
                <p>Por padrão, suas informações estão públicas. Você pode ajustar as configurações para torná-las privadas ou visíveis apenas para amigos.</p>
                <p>Os dados coletados são utilizados exclusivamente para melhorar a experiência do usuário e não são compartilhados com terceiros sem autorização explícita.</p>
            </div>
        </div>
    </div>

    <script>
        
        function carregarConfiguracoes() {
            const modoEscuro = localStorage.getItem('modoEscuro') === 'true';
            const notificacoes = localStorage.getItem('notificacoes') === 'true';
            const privacidade = localStorage.getItem('privacidade') || 'Pública';

            document.getElementById('modoEscuro').checked = modoEscuro;
            document.getElementById('notificacoes').checked = notificacoes;
            document.getElementById('privacidade').value = privacidade;

            
            if (modoEscuro) {
                document.body.classList.add('modo-escuro');
            } else {
                document.body.classList.remove('modo-escuro');
            }
        }

        
        function salvarConfiguracoes() {
            const modoEscuro = document.getElementById('modoEscuro').checked;
            const notificacoes = document.getElementById('notificacoes').checked;
            const privacidade = document.getElementById('privacidade').value;

            localStorage.setItem('modoEscuro', modoEscuro);
            localStorage.setItem('notificacoes', notificacoes);
            localStorage.setItem('privacidade', privacidade);

            alert('Configurações salvas com sucesso!');
            carregarConfiguracoes(); 
        }

        
        window.onload = carregarConfiguracoes;
    </script>
</body>
</html>
