<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendário Empresa</title>
    <style>
        @charset "UTF-8";

        .calendar-wrapper * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4; 
        }

        .calendar-wrapper {
            display: flex;
            justify-content: space-between; 
            align-items: flex-start;
            background-color: #ffffff; 
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 40px auto;
            max-width: 900px;
        }

        .calendar-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 60%;
        }

        .reminder-form {
            background-color: #eae6e6;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 8px 8px rgba(0, 0, 0, 0.1);
            width: 35%;
            margin-left: 20px; 
        }

        .calendar-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .calendar-header h2 {
            font-size: 1.5rem;
            color: #333;
        }

        .calendar-header button {
            padding: 5px 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .calendar-header button:hover {
            background-color: #0056b3;
        }

        .day-names, 
        .days {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 5px;
            text-align: center;
            padding: 0;
            list-style-type: none;
            color: #333;
        }

        .day-names li, 
        .days li {
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 4px;
        }

        .sunday {
            color: red;
        }

        .days li {
            cursor: pointer;
        }

        .days li:hover {
            background-color: #e0e0e0;
        }

        .days li.reminder {
            background-color: #b3a9cc;
        }

        .reminder-form h3 {
            margin-bottom: 10px;
            color: #333;
        }

        .reminder-form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .reminder-form button {
            padding: 10px;
            width: 100%;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .reminder-form button:hover {
            background-color: #0056b3;
        }

        .reminder-list {
            margin-top: 10px;
            font-size: 0.9rem;
        }

        .reminder-list ul {
            list-style: none;
            padding: 0;
        }

        .reminder-list li {
            background-color: #f9f9f9;
            padding: 5px;
            margin-bottom: 5px;
            border-radius: 4px;
        }

    </style>
</head>
<body>
    <div class="calendar-wrapper">
        
        <div class="calendar-container">
            <div class="calendar-header">
                <button id="prev-month">&lt;</button>
                <h2 id="month-year"></h2>
                <button id="next-month">&gt;</button>
            </div>
            <ul class="day-names">
                <li>Dom</li>
                <li>Seg</li>
                <li>Ter</li>
                <li>Qua</li>
                <li>Qui</li>
                <li>Sex</li>
                <li>Sáb</li>
            </ul>
            <ul class="days" id="days"></ul>
        </div>

       
        <div class="reminder-form" id="reminder-form">
            <h3>Adicionar Lembrete</h3>
            <p id="selected-date"></p>
            <input type="text" id="reminder-text" placeholder="Digite seu lembrete">
            <button id="add-reminder">ADICIONAR</button>
            <div class="reminder-list">
                <h4>Lembretes:</h4>
                <ul id="reminders"></ul>
            </div>
        </div>
    </div>

    <script>
        const daysElement = document.getElementById('days');
        const monthYearElement = document.getElementById('month-year');
        const prevMonthButton = document.getElementById('prev-month');
        const nextMonthButton = document.getElementById('next-month');
        const reminderForm = document.getElementById('reminder-form');
        const reminderText = document.getElementById('reminder-text');
        const remindersList = document.getElementById('reminders');
        const selectedDateElement = document.getElementById('selected-date');

        let currentDate = new Date();
        const reminders = {};

        function renderCalendar() {
            const year = currentDate.getFullYear();
            const month = currentDate.getMonth();
            const firstDay = new Date(year, month, 1).getDay();
            const lastDate = new Date(year, month + 1, 0).getDate();

            const monthNames = [
                'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 
                'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
            ];
            monthYearElement.textContent = `${monthNames[month]} ${year}`;
            daysElement.innerHTML = '';

            for (let i = 0; i < firstDay; i++) {
                const emptyCell = document.createElement('li');
                daysElement.appendChild(emptyCell);
            }

            for (let day = 1; day <= lastDate; day++) {
                const dayCell = document.createElement('li');
                dayCell.textContent = day;
                dayCell.dataset.date = `${year}-${month + 1}-${day}`;
                dayCell.classList.add('day');
                if (reminders[dayCell.dataset.date]) {
                    dayCell.classList.add('reminder');
                }
                dayCell.addEventListener('click', () => openReminderForm(dayCell.dataset.date));
                daysElement.appendChild(dayCell);
            }
        }

        function openReminderForm(date) {
            selectedDateElement.textContent = `Lembretes para: ${date}`;
            reminderForm.dataset.selectedDate = date;
            renderReminders(date);
        }

        function renderReminders(date) {
            remindersList.innerHTML = '';
            const dateReminders = reminders[date] || [];
            dateReminders.forEach((reminder) => {
                const li = document.createElement('li');
                li.textContent = reminder;
                remindersList.appendChild(li);
            });
        }

        document.getElementById('add-reminder').addEventListener('click', () => {
            const date = reminderForm.dataset.selectedDate;
            if (!reminders[date]) reminders[date] = [];
            reminders[date].push(reminderText.value);
            reminderText.value = '';
            renderReminders(date);
            renderCalendar();
        });

        prevMonthButton.addEventListener('click', () => {
            currentDate.setMonth(currentDate.getMonth() - 1);
            renderCalendar();
        });

        nextMonthButton.addEventListener('click', () => {
            currentDate.setMonth(currentDate.getMonth() + 1);
            renderCalendar();
        });

        renderCalendar();
    </script>
</body>
</html>
