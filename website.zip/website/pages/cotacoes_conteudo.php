<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gerenciamento de Cotações</title>
  <style>
    
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f5f5f5;
    }

    .container {
      max-width: 900px;
      margin: 40px auto;
      background: #ffffff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      margin-left: 250px;
    }

    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 30px;
      font-size: 24px;
    }

    .tabs {
      display: flex;
      justify-content: space-around;
      margin-bottom: 30px;
    }

    .tab-button {
      padding: 12px 25px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
      margin: 0 10px;
    }

    .tab-button.active {
      background: #0056b3;
    }

    .tab-content {
      display: none;
    }

    .tab-content.active {
      display: block;
    }

    form {
      margin-bottom: 30px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 15px;
      width: 100%;
    }

    form input, form button {
      padding: 12px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 5px;
      width: 100%;
      max-width: 300px;
    }

    form button {
      background-color: #6c757d;
      color: white;
      cursor: pointer;
      max-width: 300px;
    }

    form button:hover {
      background-color: #5a6268;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    table th, table td {
      border: 1px solid #ddd;
      padding: 12px;
      text-align: center;
      font-size: 16px;
    }

    table th {
      background-color: #f4f4f4;
      font-weight: bold;
    }

    .file-upload {
      margin-top: 30px;
      text-align: center;
    }

    .file-upload input {
      margin-right: 10px;
    }

    .file-upload button {
      background-color: #007bff;
      color: white;
      cursor: pointer;
      padding: 10px 20px;
      border-radius: 5px;
      border: none;
    }

    .file-upload button:hover {
      background-color: #0056b3;
    }

    #authorized h3, #unauthorized h3 {
      text-align: center;
      font-size: 18px;
      margin-bottom: 20px;
    }

    .file-upload h2 {
      font-size: 18px;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Gerenciamento de Cotações</h1>

    <div class="tabs">
      <button class="tab-button active" data-tab="pending">Cotações Pendentes</button>
      <button class="tab-button" data-tab="completed">Cotações Realizadas</button>
      <button class="tab-button" data-tab="authorized">Compras Autorizadas</button>
      <button class="tab-button" data-tab="unauthorized">Compras Não Autorizadas</button>
    </div>

    
    <div class="tab-content active" id="pending">
      <h2>Cotações Pendentes</h2>
      <form id="form-add-quote">
        <input type="text" id="quote-description" placeholder="Descrição da Cotação" required>
        <input type="number" id="quote-value" placeholder="Valor Estimado" required>
        <input type="date" id="quote-deadline" placeholder="Prazo" required>
        <button type="submit">Adicionar Cotação</button>
      </form>
      <table id="pending-table">
        <thead>
          <tr>
            <th>Descrição</th>
            <th>Valor Est.</th>
            <th>Prazo</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
    </div>

    
    <div class="tab-content" id="completed">
      <h3>Realizar Nova Cotação</h3>
      <form id="form-add-realized-quote">
        <input type="text" id="quote-description-realized" placeholder="Descrição da Cotação" required>
        <input type="number" id="quote-lowest-value" placeholder="Menor Valor" required>
        <input type="number" id="quote-highest-value" placeholder="Maior Valor" required>
        <input type="date" id="quote-deadline-realized" placeholder="Prazo de Entrega" required>
        <button type="submit">Adicionar Cotação</button>
      </form>
      <table id="completed-table">
        <thead>
          <tr>
            <th>Descrição</th>
            <th>Menor Val</th>
            <th>Maior Val</th>
            <th>Fornecedores</th>
            <th>Obs/Prazos</th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
    </div>

    
    <div class="tab-content" id="authorized">
      <h3>Adicionar Compra Autorizada</h3>
      <form id="form-add-authorized-purchase">
        <input type="text" id="purchase-description" placeholder="Descrição da Compra" required>
        <input type="number" id="approved-value" placeholder="Valor Aprovado" required>
        <input type="text" id="supplier" placeholder="Fornecedor" required>
        <input type="text" id="authorized-by" placeholder="Autorizado por" required>
        <button type="submit">Adicionar Compra</button>
      </form>
      <table id="authorized-table">
        <thead>
          <tr>
            <th>Descrição</th>
            <th>Valor Aprovado</th>
            <th>Fornecedor</th>
            <th>Autorizado Por</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Compra de agulhas</td>
            <td>R$ -</td>
            <td>xxx</td>
            <td>Marcelle</td>
          </tr>
          <tr>
            <td>Compra de álcool 70%</td>
            <td>R$ -</td>
            <td>xxx</td>
            <td>Diretor X</td>
          </tr>
        </tbody>
      </table>
      <div class="file-upload">
        <h2>Por favor, anexe a assinatura do diretor</h2>
        <input type="file" id="signature-file" accept="image/*,application/pdf">
        <button>Enviar</button>
      </div>
    </div>

    
    <div class="tab-content" id="unauthorized">
      <h3>Adicionar Compra Não Autorizada</h3>
      <form id="form-add-unauthorized-purchase">
        <input type="text" id="unauthorized-purchase-description" placeholder="Descrição da Compra" required>
        <input type="number" id="unauthorized-approved-value" placeholder="Valor Estimado" required>
        <input type="text" id="unauthorized-supplier" placeholder="Fornecedor" required>
        <input type="text" id="unauthorized-reason" placeholder="Motivo da Não Autorização" required>
        <button type="submit">Adicionar Compra</button>
      </form>
      <table id="unauthorized-table">
        <thead>
          <tr>
            <th>Descrição</th>
            <th>Valor Estimado</th>
            <th>xxx</th>
            <th>Motivo</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Compra de luvas descartáveis</td>
            <td>R$ -</td>
            <td>xxx</td>
            <td>Orçamento Insuficiente</td>
          </tr>
          <tr>
            <td>Compra de termômetros</td>
            <td>R$ -</td>
            <td>xxx</td>
            <td>Fornecedor Não Confiável</td>
          </tr>
        </tbody>
      </table>
      <div class="file-upload">
        <h2>Por favor, anexe os documentos justificativos</h2>
        <input type="file" id="unauthorized-documents" accept="image/*,application/pdf">
        <button>Enviar</button>
      </div>
    </div>
  </div>

  <script>
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        document.querySelector('.tab-button.active').classList.remove('active');
        button.classList.add('active');

        document.querySelector('.tab-content.active').classList.remove('active');
        document.getElementById(button.getAttribute('data-tab')).classList.add('active');
      });
    });
  </script>
</body>
</html>
