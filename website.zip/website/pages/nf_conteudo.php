<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NFs</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }

        .container {
            margin-left: 250px; 
            padding: 20px;
        }

        header {
            background-color: #007BFF;
            padding: 15px;
            color: white;
            text-align: center;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        header h1 {
            font-size: 2rem;
        }

        nav ul {
            list-style-type: none;
            padding: 10px 0;
        }

        nav ul li {
            display: inline;
            margin: 0 15px;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-size: 1.1rem;
        }

        h2 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: #007BFF;
        }

        section {
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th,
        table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        table th {
            background-color: #007BFF;
            color: white;
        }

        .nota-actions {
            margin-bottom: 20px;
        }

        .add-nota-btn {
            background-color: #007BFF;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
        }

        .add-nota-btn:hover {
            background-color: #0056b3;
        }

        .view-nota-btn, .download-nota-btn {
            background-color: #808080;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9rem;
        }

        .view-nota-btn:hover, .download-nota-btn:hover {
            background-color: #0056b3;
        }

        .download-nota-btn {
            background-color: #007BFF;
        }

        .download-nota-btn:hover {
            background-color: #0056b3;
        }

        .consultas-notas {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .consulta-link {
            color: #007BFF;
            text-decoration: none;
        }

        .consulta-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Notas Fiscais - MEDCA</h1>
            <nav>
                <ul>
                    <li><a href="/website/pages/index.php">Página Inicial</a></li>
                    <li><a href="#">Emissão de Notas Fiscais</a></li>
                    <li><a href="#">Consultas de Notas Fiscais</a></li>
                    <li><a href="/website/pages/relatorios.php">Relatórios Financeiros</a></li>
                </ul>
            </nav>
        </header>

        <section class="notas-fiscais-info">
            <h2>Informações de Notas Fiscais Emitidas</h2>
            <div class="nota-actions">
                <button class="add-nota-btn">Emitir Nova Nota Fiscal</button>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Número da Nota</th>
                        <th>Data de Emissão</th>
                        <th>Valor</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>100001</td>
                        <td>01/12/2024</td>
                        <td>R$ 1.500,00</td>
                        <td>Emitida</td>
                        <td>
                            <button class="view-nota-btn">Visualizar</button>
                            <button class="download-nota-btn">Baixar PDF</button>
                        </td>
                    </tr>
                    <tr>
                        <td>100002</td>
                        <td>02/12/2024</td>
                        <td>R$ 2.000,00</td>
                        <td>Emitida</td>
                        <td>
                            <button class="view-nota-btn">Visualizar</button>
                            <button class="download-nota-btn">Baixar PDF</button>
                        </td>
                    </tr>
                    <tr>
                        <td>100003</td>
                        <td>03/12/2024</td>
                        <td>R$ 700,00</td>
                        <td>Cancelada</td>
                        <td>
                            <button class="view-nota-btn">Visualizar</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </section>

        <section class="consultas-notas">
            <h2>Consulta de Notas Fiscais</h2>
            <p>Para consultas, acesse: 
                <a href="https://iss.fortaleza.ce.gov.br/grpfor/login.seam?cid=917425" target="_blank" class="consulta-link">
                    https://iss.fortaleza.ce.gov.br/grpfor/login.seam?cid=917425
                </a>
            </p>
        </section>
    </div>
</body>
</html>
