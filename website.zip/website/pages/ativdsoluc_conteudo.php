<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Atividades Solucionadas</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
      color: #343a40;
    }

    header {
      background-color: #007bff;
      color: white;
      text-align: center;
      padding: 20px;
    }

    header h1 {
      font-size: 24px;
      margin-bottom: 10px;
    }

    main {
      max-width: 1000px;
      margin: 20px auto;
      padding: 20px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    h2 {
      font-size: 20px;
      margin-bottom: 20px;
      color: #333;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    table th, table td {
      padding: 12px;
      border: 1px solid #dee2e6;
      text-align: center;
      font-size: 14px;
    }

    table th {
      background-color: #f1f1f1;
      font-weight: bold;
    }

    table td {
      background-color: #ffffff;
    }

    table tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    button {
      padding: 12px 20px;
      background-color: #6c757d;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #5a6268;
    }

    .actions {
      display: flex;
      justify-content: flex-end;
    }

    .actions button {
      margin-left: 10px;
    }
  </style>
</head>
<body>
  <header>
    <h1>Tarefas Solucionadas</h1>
  </header>

  <main>
    <section id="solved-activities-section">
      <h2>Lista de Atividades Solucionadas</h2>
      <table id="solved-activities-table">
        <thead>
          <tr>
            <th>Descrição</th>
            <th>Usuário</th>
            <th>Prazo</th>
            <th>Data da Solução</th>
            <th>Solucionado Por</th>
          </tr>
        </thead>
        <tbody id="solved-activities">
        </tbody>
      </table>
      <div class="actions">
        <button id="download-btn">Baixar como Planilha</button>
      </div>
    </section>
  </main>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
  <script src="script.js"></script>

  <script>
    const solvedActivities = [
      {
        description: "Conferir estoque",
        user: "Marcelle Moura",
        deadline: "-",
        solvedDate: "-",
        solvedBy: "Gestão",
      },
      {
        description: "Revisar produtos vencidos",
        user: "-",
        deadline: "-",
        solvedDate: "-",
        solvedBy: "Marcos",
      },
      {
        description: "Organizar dossies",
        user: "-",
        deadline: "-",
        solvedDate: "-",
        solvedBy: "Marcelle",
      },
    ];

    function renderSolvedActivities() {
      const tbody = document.getElementById("solved-activities");
      tbody.innerHTML = "";

      solvedActivities.forEach((activity) => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${activity.description}</td>
          <td>${activity.user}</td>
          <td>${activity.deadline}</td>
          <td>${activity.solvedDate}</td>
          <td>${activity.solvedBy}</td>
        `;
        tbody.appendChild(row);
      });
    }

    document.getElementById("download-btn").addEventListener("click", () => {
      const table = document.getElementById("solved-activities-table");
      const workbook = XLSX.utils.table_to_book(table, { sheet: "Atividades Solucionadas" });
      XLSX.writeFile(workbook, "atividades_solucionadas.xlsx");
    });

    renderSolvedActivities();
  </script>
</body>
</html>
