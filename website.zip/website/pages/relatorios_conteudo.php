<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Relatórios - MEDCA</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }

    .container {
      max-width: 1000px;
      margin: 20px auto;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    h1 {
      text-align: center;
      color: #333;
      font-size: 28px;
      margin-bottom: 20px;
    }

    h2 {
      font-size: 20px;
      color: #444;
      margin-bottom: 15px;
      border-bottom: 2px solid #007bff;
      padding-bottom: 5px;
    }

    h3 {
      font-size: 18px;
      color: #333;
      margin-bottom: 10px;
    }

    .tabs {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 25px;
    }

    .tab-button {
      padding: 10px 20px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .tab-button.active {
      background-color: #0056b3;
    }

    .tab-button:hover {
      background-color: #0069d9;
    }

    .tab-content {
      display: none;
    }

    .tab-content.active {
      display: block;
    }

    .inventory-summary {
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 15px;
      font-size: 16px;
      background: #f9f9f9;
      padding: 15px;
      border: 1px solid #ddd;
      border-radius: 5px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      font-size: 14px;
    }

    table th, table td {
      border: 1px solid #ddd;
      padding: 10px;
      text-align: center;
    }

    table th {
      background-color: #007bff;
      color: white;
      text-transform: uppercase;
    }

    table tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    table tr:hover {
      background-color: #f1f1f1;
    }

    .file-upload {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 10px;
      margin-top: 20px;
    }

    button {
      padding: 10px 20px;
      font-size: 16px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      background-color: #007bff;
      color: white;
      transition: background-color 0.3s;
    }

    button:hover {
      background-color: #0056b3;
    }

    #upload-status p {
      font-size: 14px;
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Relatórios de Estoque</h1>

    <div class="tabs">
      <button class="tab-button active" data-tab="inventory">Inventários</button>
      <button class="tab-button" data-tab="purchase-calculations">Cálculos de Compras</button>
      <button class="tab-button" data-tab="upload">Anexar Relatório</button>
    </div>

    <div class="tab-content active" id="inventory">
      <h2>Relatórios de Inventário</h2>
      <div class="inventory-summary">
        <div>Total de produtos: <span id="total-products">0</span></div>
        <div>Valor total do estoque: R$ <span id="total-value">0.00</span></div>
        <div>Produtos abaixo do estoque mínimo: <span id="low-stock-count">0</span></div>
      </div>

      
      <div class="search-container" style="margin-top: 20px;">
        <input
          type="text"
          id="search-input"
          placeholder="Pesquisar produto"
          style="padding: 10px; width: calc(100% - 20px); border: 1px solid #ddd; border-radius: 5px;"
        />
      </div>

      <table id="inventory-table">
        <thead>
          <tr>
            <th>Produto</th>
            <th>Quantidade</th>
            <th>Estoque Mínimo</th>
            <th>Valor Unitário</th>
            <th>Valor Total</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td colspan="5">Nenhum dado disponível.</td>
          </tr>
        </tbody>
      </table>

      
      <div class="add-product-container" style="margin-top: 30px;">
        <h3>Adicionar Novo Produto</h3>
        <form id="add-product-form">
          <div style="margin-bottom: 10px;">
            <input
              type="text"
              id="product-name"
              placeholder="Nome do Produto"
              style="padding: 8px; width: 100%; border: 1px solid #ddd; border-radius: 5px;"
            />
          </div>
          <div style="margin-bottom: 10px;">
            <input
              type="number"
              id="product-quantity"
              placeholder="Quantidade"
              style="padding: 8px; width: 100%; border: 1px solid #ddd; border-radius: 5px;"
            />
          </div>
          <div style="margin-bottom: 10px;">
            <input
              type="number"
              id="min-stock"
              placeholder="Estoque Mínimo"
              style="padding: 8px; width: 100%; border: 1px solid #ddd; border-radius: 5px;"
            />
          </div>
          <div style="margin-bottom: 10px;">
            <input
              type="number"
              id="unit-value"
              placeholder="Valor Unitário (R$)"
              step="0.01"
              style="padding: 8px; width: 100%; border: 1px solid #ddd; border-radius: 5px;"
            />
          </div>
          <button
            type="button"
            onclick="addProduct()"
            style="padding: 10px; width: 100%; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;"
          >
            Adicionar Produto
          </button>
        </form>
      </div>
    </div>

    <div class="tab-content" id="purchase-calculations">
      <h2>Cálculos de Compras Realizadas</h2>
      <table id="purchase-table">
        <thead>
          <tr>
            <th>Produto</th>
            <th>Quantidade Comprada</th>
            <th>Valor Unitário</th>
            <th>Valor Total</th>
            <th>Data da Compra</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td colspan="5">Nenhuma compra registrada.</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="tab-content" id="upload">
      <h2>Anexar Relatórios de Invetários e Cálc. de Comp.</h2>
      <div class="file-upload">
        <input type="file" id="report-file">
        <button onclick="uploadReport()">Anexar Relatório</button>
      </div>
      <div id="upload-status"></div>
    </div>
  </div>
<script>
function switchTab(tabName) {
  document.querySelectorAll(".tab-content").forEach((content) => {
    content.classList.remove("active");
  });

  document.querySelectorAll(".tab-button").forEach((button) => {
    button.classList.remove("active");
  });

  document.getElementById(tabName).classList.add("active");
  document.querySelector(`.tab-button[data-tab="${tabName}"]`).classList.add("active");
}

document.querySelectorAll(".tab-button").forEach((button) => {
  button.addEventListener("click", () => {
    switchTab(button.dataset.tab);
  });
});
const inventoryData = {
  totalProducts: 2,
  totalValue: 127,
  lowStock: [
    { name: "Produto -", quantity: 5, minStock: 10, unitValue: 15.5 },
    { name: "Produto -", quantity: 2, minStock: 5, unitValue: 25.0 }
  ],
  purchases: [
    { product: "Produto -", quantity: 20, unitValue: 10.0, totalValue: 200, date: "2024-11-15" },
    { product: "Produto -", quantity: 10, unitValue: 50.0, totalValue: 500, date: "2024-11-14" }
  ]
};

function updateInventorySummary() {
  document.getElementById("total-products").textContent = inventoryData.totalProducts;
  document.getElementById("total-value").textContent = inventoryData.totalValue.toFixed(2);
  document.getElementById("low-stock-count").textContent = inventoryData.lowStock.length;
}

function updateInventoryTable() {
  const tableBody = document.querySelector("#inventory-table tbody");
  tableBody.innerHTML = "";

  if (inventoryData.lowStock.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="5">Nenhum dado disponível.</td></tr>`;
    return;
  }

  inventoryData.lowStock.forEach((product) => {
    const totalValue = (product.quantity * product.unitValue).toFixed(2);
    tableBody.innerHTML += `<tr>
      <td>${product.name}</td>
      <td>${product.quantity}</td>
      <td>${product.minStock}</td>
      <td>R$ ${product.unitValue.toFixed(2)}</td>
      <td>R$ ${totalValue}</td>
    </tr>`;
  });
}

function uploadReport() {
  const fileInput = document.getElementById("report-file");
  const statusDiv = document.getElementById("upload-status");

  if (!fileInput.files.length) {
    statusDiv.innerHTML = `<p style="color: red;">Nenhum arquivo selecionado</p>`;
    return;
  }

  const file = fileInput.files[0];
  statusDiv.innerHTML = `<p style="color: green;">Arquivo "${file.name}" anexado com sucesso</p>`;
  fileInput.value = ""; 
}

document.querySelectorAll(".tab-button").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".tab-button").forEach((btn) => btn.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach((content) => content.classList.remove("active"));

    button.classList.add("active");
    document.getElementById(button.dataset.tab).classList.add("active");
  });
});

updateInventorySummary();
updateInventoryTable();
</script>
</body>
</html>
