<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Atividades Pendentes</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
      color: #343a40;
    }

    header {
      background-color: #007bff;
      color: white;
      text-align: center;
      padding: 15px;
    }

    header h1 {
      font-size: 22px;
      margin-bottom: 10px;
    }

    main {
      max-width: 900px;
      margin: 20px auto;
      padding: 20px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    h2 {
      font-size: 18px;
      margin-bottom: 15px;
      color: #333;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    table th, table td {
      padding: 10px;
      border: 1px solid #dee2e6;
      text-align: center;
      font-size: 14px;
    }

    table th {
      background-color: #f1f1f1;
      font-weight: 600;
    }

    table td {
      background-color: #ffffff;
    }

    table tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    button {
      padding: 10px 20px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
      width: auto;
    }

    button:hover {
      background-color: #0056b3;
    }

    form {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      justify-content: flex-start;
      margin-bottom: 20px;
    }

    form input, form select, form button {
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 14px;
    }

    form input, form select {
      width: 200px;
    }

    form button {
      background-color: #6c757d;
      color: white;
      cursor: pointer;
      margin-left: auto;
    }

    form button:hover {
      background-color: #5a6268;
    }

    #reminder-form label {
      font-weight: 600;
      font-size: 14px;
      margin-right: 10px;
    }

    #reminder-section {
      margin-top: 40px;
      padding: 20px;
      background-color: #f1f1f1;
      border-radius: 8px;
    }

  </style>
</head>
<body>
  <header>
    <h1>Gestão de Atividades</h1>
  </header>

  <main>
    <section id="pending-activities-section">
      <h2>Lista de Atividades Pendentes</h2>
      <table id="pending-activities-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Descrição</th>
            <th>Responsável</th>
            <th>Aberto Por</th>
            <th>Prazo</th>
            <th>Motivo</th>
          </tr>
        </thead>
        <tbody id="pending-activities">
        </tbody>
      </table>
      <button id="download-btn">Baixar como Planilha</button>
    </section>

    <section id="reminder-section">
      <h2>Enviar Lembrete</h2>
      <form id="reminder-form">
        <div>
          <label for="activity-id">ID da Atividade:</label>
          <input type="number" id="activity-id" required>
        </div>
        <div>
          <label for="user">Enviar Lembrete Para:</label>
          <select id="user" required>
            <option value="Marcelle Moura">Marcelle Moura</option>
            <option value="Marcos">Marcos</option>
            <option value="Gestão">Gestão</option>
          </select>
        </div>
        <button type="submit">Enviar Lembrete</button>
      </form>
    </section>
  </main>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
  <script src="script.js"></script>

  <script>
    const pendingActivities = [
      {
        id: 1,
        description: "Conferir estoque",
        responsible: "Marcelle Moura",
        openedBy: "-",
        deadline: "-",
        reason: "Falta de tempo",
      },
      {
        id: 2,
        description: "Revisar produtos vencidos",
        responsible: "-",
        openedBy: "-",
        deadline: "-",
        reason: "Prioridade baixa",
      },
      {
        id: 3,
        description: "Organizar dossies",
        responsible: "-",
        openedBy: "-",
        deadline: "-",
        reason: "Aguardando materiais",
      },
    ];

    function renderPendingActivities() {
      const tbody = document.getElementById("pending-activities");
      tbody.innerHTML = "";

      pendingActivities.forEach((activity) => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${activity.id}</td>
          <td>${activity.description}</td>
          <td>${activity.responsible}</td>
          <td>${activity.openedBy}</td>
          <td>${activity.deadline}</td>
          <td>${activity.reason}</td>
        `;
        tbody.appendChild(row);
      });
    }

    document.getElementById("download-btn").addEventListener("click", () => {
      const table = document.getElementById("pending-activities-table");
      const workbook = XLSX.utils.table_to_book(table, { sheet: "Atividades Pendentes" });
      XLSX.writeFile(workbook, "atividades_pendentes.xlsx");
    });

    document.getElementById("reminder-form").addEventListener("submit", (e) => {
      e.preventDefault();

      const activityId = parseInt(document.getElementById("activity-id").value);
      const activity = pendingActivities.find((act) => act.id === activityId);
      const user = document.getElementById("user").value;

      if (activity) {
        alert(`Lembrete enviado para ${user} sobre a atividade: "${activity.description}".`);
      } else {
        alert("Atividade não encontrada.");
      }

      e.target.reset();
    });

    renderPendingActivities();
  </script>
</body>
</html>
