<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Perfil Usuário</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f9;
      display: flex;
      flex-direction: column; 
      height: 100vh; 
    }

    
    .content-container {
      flex-grow: 1; 
      display: flex;
      justify-content: center; 
      align-items: center; 
      padding-top: 60px; 
    }

    .container {
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 600px;
    }

    h1 {
      text-align: center;
      color: #333;
    }

    .profile-view, .profile-edit {
      display: none;
    }

    .active {
      display: block;
    }

    .profile-info {
      margin: 20px 0;
    }

    .profile-info p {
      margin: 8px 0;
      color: #555;
    }

    form {
      display: flex;
      flex-direction: column;
    }

    label {
      margin-top: 15px;
      font-weight: bold;
      color: #555;
    }

    input[type="text"], input[type="email"], input[type="password"] {
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    .button-group {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
    }

    button {
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }

    .edit-btn {
      background-color: #007BFF;
      color: white;
    }

    .save-btn {
      background-color: #007BFF;
      color: white;
    }

    .cancel-btn {
      background-color: #dc3545;
      color: white;
    }

    button:hover {
      opacity: 0.9;
    }
  </style>
</head>
<body>

  
  <div class="content-container">
    <div class="container">
      <h1>Visualizar e editar:</h1>

      
      <div class="profile-view active" id="profileView">
        <div class="profile-info">
          <p><strong>Nome:</strong> <span id="viewName">Admin</span></p>
          <p><strong>Email:</strong> <span id="viewEmail">admin@admin.com</span></p>
        </div>
        <div class="button-group">
          <button class="edit-btn" id="editButton">Editar Perfil</button>
        </div>
      </div>

      
      <div class="profile-edit" id="profileEdit">
        <form id="editProfileForm">
          <label for="name">Nome:</label>
          <input type="text" id="name" name="name" placeholder="Digite seu nome" required>

          <label for="email">Email:</label>
          <input type="email" id="email" name="email" placeholder="Digite seu email" required>

          <label for="password">Senha:</label>
          <input type="password" id="password" name="password" placeholder="Digite sua senha (opcional)">
          <p class="password-reminder">
            * A senha deve ter no mínimo 8 caracteres, incluir letras maiúsculas e minúsculas, números e caracteres especiais, como !, @, #, $, etc.
          </p>

          <div class="profile-container">
            <h2>Alterar Foto de Perfil</h2>
            <img id="profileImage" class="profile-image" src="https://via.placeholder.com/150" alt="Foto de Perfil">
            <br>
            <input type="file" id="fileInput" accept="image/*">
            <br>
            <button type="button" onclick="alterarFoto()">Alterar Foto</button>
          </div>

          <div class="button-group">
            <button type="button" class="cancel-btn" id="cancelButton">Cancelar</button>
            <button type="submit" class="save-btn">Salvar Alterações</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script>
    const profileView = document.getElementById('profileView');
    const profileEdit = document.getElementById('profileEdit');
    const editButton = document.getElementById('editButton');
    const cancelButton = document.getElementById('cancelButton');
    const editProfileForm = document.getElementById('editProfileForm');

    let userProfile = {
      name: 'Admin',
      email: 'admin@admin.com'
    };

    
    function updateProfileView() {
      document.getElementById('viewName').textContent = userProfile.name;
      document.getElementById('viewEmail').textContent = userProfile.email;
    }

    
    editButton.addEventListener('click', () => {
      profileView.classList.remove('active');
      profileEdit.classList.add('active');
      document.getElementById('name').value = userProfile.name;
      document.getElementById('email').value = userProfile.email;
    });

    
    cancelButton.addEventListener('click', () => {
      profileEdit.classList.remove('active');
      profileView.classList.add('active');
    });

    
    function alterarFoto() {
      const fileInput = document.getElementById('fileInput');
      const profileImage = document.getElementById('profileImage');

      if (fileInput.files && fileInput.files[0]) {
        const reader = new FileReader();

        reader.onload = function (e) {
          profileImage.src = e.target.result; 
        };

        reader.readAsDataURL(fileInput.files[0]);
      }
    }

    
    editProfileForm.addEventListener('submit', (event) => {
      event.preventDefault();
      userProfile.name = document.getElementById('name').value;
      userProfile.email = document.getElementById('email').value;
      alert('Perfil atualizado com sucesso!');
      updateProfileView();
      profileEdit.classList.remove('active');
      profileView.classList.add('active');
    });

    updateProfileView();
  </script>

</body>
</html>
