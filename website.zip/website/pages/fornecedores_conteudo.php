<?php

$host = 'localhost';
$dbname = 'controledestoque';
$username = 'root';
$password = 'ruabreves86';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['acao'])) {
        $acao = $_POST['acao'];

        if ($acao === 'inserir') {
            $nome = $_POST['NomeFabricante'];
            $cnpj = $_POST['CNPJFabricante'];
            $email = $_POST['EmailFabricante'];
            $endereco = $_POST['EndereçoFabricante'];
            $telefone = $_POST['TelefoneFabricante'];
            $usuario = $_POST['Usuario_idUser'];

            $stmt = $pdo->prepare("INSERT INTO fabricante (`NomeFabricante`, `CNPJFabricante`, `EmailFabricante`, `EndereçoFabricante`, `TelefoneFabricante`, Usuario_idUser) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$nome, $cpnj, $email, $endereco, $telefone, $usuario]);
        } elseif ($acao === 'editar') {
            $id = $_POST['idFabricante'] ?? null;  // ?? para garantir que o índice existe
            $nome = $_POST['NomeFabricante'];
            $cnpj = $_POST['CNPJFabricante'];
            $email = $_POST['EmailFabricante'];
            $endereco = $_POST['EndereçoFabricante'];
            $telefone = $_POST['TelefoneFabricante'];
            $usuario = $_POST['Usuario_idUser'];

            if ($id) {
                $stmt = $pdo->prepare("UPDATE fabricante SET `NomeFabricante` = ?, `CNPJFabricante` = ?, `EmailFabricante` = ?, `EndereçoFabricante` = ?, `TelefoneFabricante` = ?, `Usuario_idUser` = ? WHERE `idFabricante` = ?");
                $stmt->execute([$nome, $cpnj, $email, $endereco, $telefone, $usuario, $id]);
            } else {
                echo "ID do usuário não foi fornecido para edição.";
            }
        } elseif ($acao === 'excluir') {
            $id = $_POST['idFabricante'] ?? null; // ?? para garantir que o índice existe

            if ($id) {
                $stmt = $pdo->prepare("DELETE FROM fabricante WHERE `idFabricante` = ?");
                $stmt->execute([$id]);
            } else {
                echo "ID do usuário não foi fornecido para exclusão.";
            }
        }
    }
}

$stmt = $pdo->query("SELECT * FROM fabricante");
$usuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gerenciamento de Fornecedores</title>

  <style>
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
      display: flex;
      min-height: 100vh;
      flex-direction: column;
    }

    
    .main-container {
      display: flex;
      flex-grow: 1;
    }

    .content-wrapper {
      flex-grow: 1;
      margin-top: 60px; 
      padding: 20px;
      display: flex;
      justify-content: center;
      align-items: flex-start;
    }

    .content-inner {
      width: 100%;
      max-width: 1200px;
      padding: 20px;
      background-color: #ffffff;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
      color: #343a40;
      font-size: 30px
    }

    form {
      margin-bottom: 20px;
    }

    .form-label {
      font-weight: bold;
      margin-bottom: 5px;
      display: block;
    }

    .form-control {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ced4da;
      border-radius: 4px;
    }

    button.btn {
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }

    .btn-primary {
      background-color: #007bff;
      color: #ffffff;
    }

    .btn-primary:hover {
      background-color: #0056b3;
    }

    
    .table {
      width: 100%;
      border-collapse: collapse;
      background-color: #ffffff;
      border-radius: 8px;
      overflow: hidden;
      margin-top: 20px;
    }

    .table th, .table td {
      padding: 12px 15px;
      text-align: center; 
      font-size: 14px;
      border: 1px solid #dee2e6;
      word-wrap: break-word; 
      white-space: normal; 
      word-break: break-word; 
    }

    .table thead th {
      background-color: #007bff;
      color: #ffffff;
      font-weight: bold;
    }

    .table tbody tr:nth-child(odd) {
      background-color: #f8f9fa;
    }

    .table tbody tr:hover {
      background-color: #e9ecef;
    }

    
    .table td:nth-child(5) {
      min-width: 150px; 
      max-width: 250px; 
      text-align: center; 
    }

    .btn-warning {
      background-color: #ffc107;
      color: #212529;
    }

    .btn-warning:hover {
      background-color: #e0a800;
    }

    .btn-danger {
      background-color: #dc3545;
      color: #ffffff;
    }

    .btn-danger:hover {
      background-color: #c82333;
    }

    
    .action-buttons {
      display: flex;
      justify-content: center;
      gap: 10px;
    }
    
    .edit-btn, .delete-btn {
      width: 100px;
      padding: 8px;
      font-size: 14px;
      border-radius: 4px;
    }

  </style>
</head>

<body>

  
  <div class="main-container">

    
    <div class="content-wrapper" >
      <div class="content-inner">
        <h1>Cadastro de fornecedores</h1>

        <form method="post" id="fornecedorForm" class="mb-4">
          <input type="hidden" name="acao" value="inserir">
          <input type="hidden" name="id" id="id">

          <div class="mb-3">
            <label for="id" class="form-label">ID</label>
            <input type="number" class="form-control" name="id" id="id" required>
          </div>

          <div class="mb-3">
            <label for="nome" class="form-label">Nome do fornecedor</label>
            <input type="text" class="form-control" name="nome" id="nome" required>
          </div>
          <div class="mb-3">
            <label for="valor" class="form-label">CNPJ</label>
            <input type="number" step="0.01" class="form-control" name="valor" id="valor" required>
          </div>
          <div class="mb-3">
            <label for="quantidade" class="form-label">Email</label>
            <input type="number" class="form-control" name="quantidade" id="quantidade" required>
          </div>
          <div class="mb-3">
            <label for="categoria" class="form-label">Telefone</label>
            <input type="text" class="form-control" name="categoria" id="categoria" required>
          </div>

          <div class="mb-3">
            <label for="categoria" class="form-label">Endereço</label>
            <input type="text" class="form-control" name="categoria" id="categoria" required>
          </div>

          <button type="submit" class="btn btn-primary">Cadastrar</button>
        </form>

        <table class="table table-bordered">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nome</th>
              <th>CNPJ</th>
              <th>Email</th>
              <th>Endereço</th>
              <th>Telefone</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
                <?php foreach ($fabricante as $fabricante): ?>
                    <tr>
                        <td><?= $fabricante['idFabricante'] ?></td>
                        <td><?= $fabricante['NomeFabricante'] ?></td>
                        <td><?= $fabricante['CNPJFabricante'] ?></td>
                        <td><?= $fabricante['EmailFabricante'] ?></td>
                        <td><?= $fabricante['EndereçoFabricante'] ?></td>
                        <td><?= $fabricante['TelefoneFabricante'] ?></td>
                        <td><?= $fabricante['Usuario_idUser'] ?></td>
                        <td class="actions">
                            <button type="button" class="btn btn-warning btn-editar"
                                    data-id="<?= $fabricante['idFabricante'] ?>"
                                    data-nome="<?= $fabricante['NomeFabricante'] ?>"
                                    data-cnpj="<?= $fabricante['CNPJFabricante'] ?>"
                                    data-email="<?= $fabricante['EmailFabricante'] ?>"
                                    data-endereco="<?= $fabricante['EndereçoFabricante'] ?>"
                                    data-telefone="<?= $fabricante['TelefoneFabricante'] ?>"
                                    data-usuario="<?= $fabricante['Usuario_idUser'] ?>">Editar</button>
                            <form method="post" style="width: 48%; padding: 0; margin: 0;">
                                <input type="hidden" name="acao" value="excluir">
                                <input type="hidden" name="idFabricante" value="<?= $fabricante['idFabricante'] ?>">
                                <button type="submit" class="btn btn-danger">Excluir</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    document.querySelectorAll('.btn-editar').forEach(button => {
        button.addEventListener('click', () => {
            const form = document.querySelector('#fornecedorForm');
            document.querySelector('#acao').value = 'editar';
            document.querySelector('#idFabricante').value = button.getAttribute('data-id');
            document.querySelector('#NomeFabricante').value = button.getAttribute('data-nome');
            document.querySelector('#CNPJFabricante').value = button.getAttribute('data-cnpj');
            document.querySelector('#EmailFabricante').value = button.getAttribute('data-email');
            document.querySelector('#EndereçoFabricante').value = button.getAttribute('data-endereco');
            document.querySelector('#TelefoneFabricante').value = button.getAttribute('data-telefone');
            document.querySelector('#Usuario_idUser').value = button.getAttribute('data-usuario');
        });
    });
</script>

</body>
</html>
